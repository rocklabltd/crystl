# Crystl V1 Starter Docs

This folder contains the core documentation files for building Crystl V1 with Codex.

## Included files

- `AGENTS.md`  
  Repo level instructions for Codex

- `docs/CRYSTL_V1_BUILD_SPEC.md`  
  Product, technical, workflow, schema, route, and acceptance spec

- `docs/CRYSTL_V1_DESIGN.md`  
  UX, UI, workflow, and product behaviour design file

## Suggested next files to create

- `.env.example`
- `supabase/migrations/0001_initial_schema.sql`
- `supabase/seed.sql`
- `docs/ROUTES.md`
- `docs/DATA_MODEL.md`

## Suggested Codex workflow

1. Add these files to the repo root and `docs` folder.
2. Ask Codex to scaffold the app using the build spec and AGENTS file.
3. Have Codex create the initial Supabase schema and RLS policies.
4. Build the public request flow first.
5. Build the authenticated opportunity workflow second.
6. Add RFQs, supplier responses, and quotes after the core opportunity pages are working.
