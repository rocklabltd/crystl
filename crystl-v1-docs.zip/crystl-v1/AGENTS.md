# AGENTS.md

## Project
Crystl V1 is a multi workspace request to quote system.
The first live workspace is Supplement Lab.

## Objective
Build a production ready MVP that captures public product requests and turns them into managed opportunities, supplier RFQs, supplier responses, and customer quotes.

## Non goals
Do not build generic CRM features.
Do not add marketing pages.
Do not add AI features yet.
Do not add customer portal features yet.
Do not add deep analytics yet.

## Tech constraints
Use Next.js App Router, TypeScript, Tailwind, shadcn/ui, Supabase Auth, Supabase Postgres, Supabase Storage.
Prefer server components and server actions where sensible.
Use Zod for validation.
Keep code modular and typed.

## Multi tenancy
All tenant data must be scoped by workspace_id.
Assume future workspaces beyond Supplement Lab.
Do not hardcode supplement specific logic into the global app model.
Supplement specific fields belong in the seeded form template and structured requirement UI.

## Security
Use RLS on all tenant tables.
Do not expose service role key to client code.
Use server side actions for privileged operations.

## UX
The app is a serious internal workflow tool, not a flashy marketing app.
Prioritise clarity, speed, and low friction.

## Coding style
Keep files readable.
Prefer small reusable components.
Avoid premature abstraction.
Comment only where it genuinely helps.
Use explicit naming over clever naming.

## Acceptance
The app is complete when a public user can submit a Supplement Lab request and an authenticated workspace user can take it through the full request to quote workflow.
